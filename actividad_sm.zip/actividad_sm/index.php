<?php
echo "<h1>Servidor PHP activo en Render 🚀</h1>";
?>
